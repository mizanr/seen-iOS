import { Component } from '@angular/core';
import { ModalController } from 'ionic-angular';
import { NavController, NavParams } from 'ionic-angular';
import { DetailNextPage } from '../detail-next/detail-next';
import { NextvisitPage } from '../nextvisit/nextvisit';
import { NotificationsPage } from '../notifications/notifications';
import { ProductlistPage } from '../productlist/productlist';
import { PaymentPage } from '../payment/payment';
import { CoursePage } from '../course/course';
import { ProfileteacherPage } from '../profileteacher/profileteacher';

/**
 * Generated class for the DetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-details',
  templateUrl: 'details.html',
})
export class DetailsPage {
  active=1;

   //item = [
 //{ active(item): false },
 //];

  //item2 = [
 //{ active(item2):false },
 //];

  //active(item){
    //item.active = !item.active;
  //}
  
  //active(item2){
   // item2.active = !item2.active;
  //}


  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DetailsPage');
  }

   payment() {
    const modal = this.modalCtrl.create(PaymentPage,{},{cssClass:'moremodel', showBackdrop:true, enableBackdropDismiss:true});
     modal.present();
   }


  // place() {
  //   const modal = this.modalCtrl.create(ProductlistPage,{},{cssClass:'moremodel', //showBackdrop:true, enableBackdropDismiss:true});
  //   modal.present();
  // }
  // next(){
  //   const modal = this.modalCtrl.create(NextvisitPage,{},{cssClass:'moremodel', //showBackdrop:true, enableBackdropDismiss:true});
  //   modal.present();
  // }
  // profile(){
  //   this.navCtrl.push(ProfilePage);
  // }


  next(){
    this.nav.push(DetailNextPage);
  }

  back(){
    this.navCtrl.pop();
  }

  coursepage(){
  this.navCtrl.push(CoursePage);
  }

  profile(){
  this.navCtrl.push(ProfileteacherPage);
  }
 
}
